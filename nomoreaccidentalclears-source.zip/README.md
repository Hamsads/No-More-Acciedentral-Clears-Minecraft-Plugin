# Paper Basic Template (Minecraft 1.21.10)

Starter Paper plugin that registers a `/playergames` command and logs on enable. Targets Minecraft 1.21.10/1.21.11 with the Paper API.

## What's Included
- Main class `org.mcbirljllvuzlg.nomoreacciedentalclears.PGPlugin`
- Paper API dependency pinned to `1.21.10-R0.1-SNAPSHOT`
- Adventure API support for modern text components
- Resource filtering for `plugin.yml`

## Build
```bash
./gradlew build
```
