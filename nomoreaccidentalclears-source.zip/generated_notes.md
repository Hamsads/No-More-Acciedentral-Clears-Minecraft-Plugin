# No More Accidental Clears

## Overview
This server plugin adds a confirmation step before an authorized player’s `/clear` command can remove items.

## Features
- Players who are not operators and do not have the normal `/clear` permission cannot execute `/clear` through this protection.
- Supports `/clear confirm` and, optionally, repeating the exact clear command.
- Shows a short actionbar countdown while confirmation is available.
- Protects command-block clears when enabled.
- Confirmation methods and the confirmation delay can be changed in the configuration.

## How to Use
1. Run your normal `/clear` command.
2. Within the configured delay, either type `/clear confirm` or repeat the exact same command if that option is enabled.
3. The actionbar countdown disappears immediately after the clear is confirmed.

## What Changed in This Iteration
- Unauthorized non-operators without `minecraft.command.clear` or `bukkit.command.clear` no longer pass through the plugin’s clear handling.
- The actionbar countdown is cleared as soon as a confirmation command successfully executes the pending clear.
- Added configurable confirmation delay and switches for `/clear confirm`, repeated-command confirmation, and command-block protection.
- Confirmation messages now reflect which confirmation methods are enabled.

## Tips & Tricks
- Set `confirmation-delay-seconds` to give yourself more or less time to confirm.
- Disable either confirmation method if you want to allow only the other one.

## Known Limitations
- The normal server permission system still controls access to `/clear`; this plugin does not grant that permission.
- Configuration changes take effect after the plugin is restarted.
