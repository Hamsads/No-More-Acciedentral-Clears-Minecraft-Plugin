package org.mcbirljllvuzlg.nomoreacciedentalclears;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class PGPlugin extends JavaPlugin implements Listener {
    private static final long DEFAULT_CONFIRMATION_WINDOW_SECONDS = 10L;
    private static final String CLEAR_LABEL = "clear";
    private static final String MINECRAFT_CLEAR_LABEL = "minecraft:clear";

    private final Map<String, PendingClear> pendingClears = new HashMap<>();
    private boolean confirmCommandEnabled;
    private boolean repeatConfirmationEnabled;
    private boolean commandBlockProtectionEnabled;
    private boolean requireClearPermission;
    private long confirmationWindowSeconds;
    private int confirmedCommandDepth;
    private BukkitTask countdownTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        confirmCommandEnabled = getConfig().getBoolean("confirm-command-enabled", true);
        repeatConfirmationEnabled = getConfig().getBoolean("repeat-confirmation-enabled", true);
        commandBlockProtectionEnabled = getConfig().getBoolean("command-block-protection-enabled", true);
        requireClearPermission = getConfig().getBoolean("require-clear-permission", true);
        confirmationWindowSeconds = getConfig().getLong("confirmation-delay-seconds", DEFAULT_CONFIRMATION_WINDOW_SECONDS);
        if (confirmationWindowSeconds < 1) {
            confirmationWindowSeconds = DEFAULT_CONFIRMATION_WINDOW_SECONDS;
            getLogger().warning("confirmation-delay-seconds must be at least 1; using 10 seconds.");
        }
        getServer().getPluginManager().registerEvents(this, this);
        countdownTask = getServer().getScheduler().runTaskTimer(this, this::updateCountdowns, 1L, 1L);
        getLogger().info("Clear protection enabled.");
    }

    @Override
    public void onDisable() {
        if (countdownTask != null) {
            countdownTask.cancel();
        }
        pendingClears.clear();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        if (confirmedCommandDepth > 0) {
            return;
        }
        handleCommand(event.getPlayer(), event.getMessage(), () -> event.setCancelled(true));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onServerCommand(ServerCommandEvent event) {
        if (confirmedCommandDepth > 0) {
            return;
        }
        handleCommand(event.getSender(), event.getCommand(), () -> event.setCancelled(true));
    }

    private void handleCommand(CommandSender sender, String rawCommand, Runnable cancellation) {
        if (sender instanceof BlockCommandSender && !commandBlockProtectionEnabled) {
            return;
        }

        String commandText = withoutLeadingSlash(rawCommand);
        String label = firstWord(commandText).toLowerCase(Locale.ROOT);
        if (!isClearLabel(label)) {
            return;
        }
        if (requireClearPermission && sender instanceof Player player
                && !player.isOp() && !player.hasPermission("minecraft.command.clear")) {
            cancellation.run();
            player.sendMessage(Component.text("You do not have permission to use /clear."));
            return;
        }

        String senderKey = senderKey(sender);
        cancellation.run();
        if (isConfirmation(commandText, label)) {
            if (!confirmCommandEnabled) {
                sender.sendMessage(Component.text("The /clear confirm option is disabled."));
                return;
            }
            confirm(sender, senderKey);
            return;
        }

        PendingClear pending = pendingClears.get(senderKey);
        long now = System.nanoTime();
        if (repeatConfirmationEnabled
                && pending != null
                && pending.expiresAtNanos > now
                && pending.commandText.equals(commandText)) {
            pendingClears.remove(senderKey);
            clearActionBar(sender);
            executeOriginal(sender, pending.commandText);
            return;
        }

        pendingClears.put(senderKey, new PendingClear(sender, commandText,
                now + TimeUnit.SECONDS.toNanos(confirmationWindowSeconds), confirmationWindowSeconds));
        sendConfirmationInstructions(sender);
    }

    private void confirm(CommandSender sender, String senderKey) {
        PendingClear pending = pendingClears.get(senderKey);
        if (pending == null || pending.expiresAtNanos <= System.nanoTime()) {
            pendingClears.remove(senderKey);
            sender.sendMessage(Component.text("There is no clear waiting for confirmation."));
            return;
        }
        pendingClears.remove(senderKey);
        clearActionBar(sender);
        executeOriginal(sender, pending.commandText);
    }

    private void executeOriginal(CommandSender sender, String commandText) {
        confirmedCommandDepth++;
        try {
            Bukkit.dispatchCommand(sender, commandText);
        } finally {
            confirmedCommandDepth--;
        }
    }

    private void clearActionBar(CommandSender sender) {
        if (sender instanceof Player player) {
            player.sendActionBar(Component.empty());
        }
    }
    private void sendConfirmationInstructions(CommandSender sender) {
        if (repeatConfirmationEnabled) {
            sender.sendMessage(Component.text("Clear stopped. "
                    + (confirmCommandEnabled ? "Type /clear confirm or " : "")
                    + "repeat the exact command within "
                    + confirmationWindowSeconds + " seconds to continue."));
            if (confirmCommandEnabled && sender instanceof Player player) {
                player.sendActionBar(Component.text("Clear confirmation expires in " + confirmationWindowSeconds
                        + (confirmationWindowSeconds == 1 ? " second" : " seconds")));
            }
        } else if (confirmCommandEnabled) {
            sender.sendMessage(Component.text("Clear stopped. Type /clear confirm within " + confirmationWindowSeconds
                    + (confirmationWindowSeconds == 1 ? " second" : " seconds") + " to continue."));
            if (sender instanceof Player player) {
                player.sendActionBar(Component.text("Clear confirmation expires in " + confirmationWindowSeconds
                        + (confirmationWindowSeconds == 1 ? " second" : " seconds")));
            }
        } else {
            sender.sendMessage(Component.text("Clear stopped. Both confirmation methods are disabled in the config."));
        }
    }


    private void updateCountdowns() {
        long now = System.nanoTime();
        Iterator<Map.Entry<String, PendingClear>> iterator = pendingClears.entrySet().iterator();
        while (iterator.hasNext()) {
            PendingClear pending = iterator.next().getValue();
            long remainingNanos = pending.expiresAtNanos - now;
            if (remainingNanos <= 0) {
                iterator.remove();
                if (pending.sender instanceof Player player) {
                    player.sendActionBar(Component.empty());
                }
                continue;
            }

            if (confirmCommandEnabled && pending.sender instanceof Player player) {
                long remainingSeconds = (long) Math.ceil(remainingNanos / 1_000_000_000.0);
                if (remainingSeconds != pending.lastShownSeconds) {
                    pending.lastShownSeconds = remainingSeconds;
                    player.sendActionBar(Component.text("Clear confirmation expires in " + remainingSeconds
                            + (remainingSeconds == 1 ? " second" : " seconds")));
                }
            }
        }
    }

    private static boolean isClearLabel(String label) {
        return CLEAR_LABEL.equals(label) || MINECRAFT_CLEAR_LABEL.equals(label);
    }

    private static boolean isConfirmation(String commandText, String label) {
        if (!isClearLabel(label)) {
            return false;
        }
        String remainder = commandText.substring(firstWordEnd(commandText)).trim();
        return "confirm".equalsIgnoreCase(remainder);
    }

    private static String withoutLeadingSlash(String command) {
        if (command == null) {
            return "";
        }
        return command.startsWith("/") ? command.substring(1) : command;
    }

    private static String firstWord(String command) {
        return command.substring(0, firstWordEnd(command));
    }

    private static int firstWordEnd(String command) {
        for (int index = 0; index < command.length(); index++) {
            if (Character.isWhitespace(command.charAt(index))) {
                return index;
            }
        }
        return command.length();
    }

    private static String senderKey(CommandSender sender) {
        if (sender instanceof Player player) {
            return "player:" + player.getUniqueId();
        }
        if (sender instanceof BlockCommandSender blockCommandSender) {
            Block block = blockCommandSender.getBlock();
            return "block:" + block.getWorld().getUID() + ":" + block.getX() + ":" + block.getY() + ":" + block.getZ();
        }
        if (sender instanceof ConsoleCommandSender) {
            return "console";
        }
        return "sender:" + sender.getClass().getName() + ":" + sender.getName();
    }

    private static final class PendingClear {
        private final CommandSender sender;
        private final String commandText;
        private final long expiresAtNanos;
        private long lastShownSeconds;

        private PendingClear(CommandSender sender, String commandText, long expiresAtNanos, long confirmationWindowSeconds) {
            this.sender = sender;
            this.commandText = commandText;
            this.expiresAtNanos = expiresAtNanos;
            this.lastShownSeconds = (int) Math.min(Integer.MAX_VALUE, confirmationWindowSeconds);
        }
    }
}
